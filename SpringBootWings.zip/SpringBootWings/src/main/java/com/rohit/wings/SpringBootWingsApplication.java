package com.rohit.wings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWingsApplication.class, args);
	}

}
